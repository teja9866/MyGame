
package ass3.mygame2;


/**
 *
 * @author @version
 */


public class MyGame {

    /**
    *
    * @param nothing
    */
    public static void main(String[] args) {
        Game game = new Game();
        game.play(); 
        
    }
    
    
    
}


